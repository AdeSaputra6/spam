<p align="center">
<a href="#"><img src="https://telegra.ph/file/513705cc3b283b556ef3c.png" alt="BRUTAL SPAM WHATSAPP" width="200" height="130"/></a>


</p>
<p align="center">
<a href="#"><img title="BRUTAL SPAM WHATSAPP" src="https://img.shields.io/badge/BRUTAL SPAM WHATSAPP-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/FatihArridho?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/FatihArridho?color=red&style=flat-square"></a>
<a href="https://github.com/FatihArridho/brutal/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/FatihArridho/brutal?color=blue&style=flat-square"></a>
<a href="https://github.com/FatihArridho/brutal/network/members"><img title="Forks" src="https://img.shields.io/github/forks/FatihArridho/brutal?color=red&style=flat-square"></a>
<a href="https://github.com/FatihArridho/brutal/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/FatihArridho/brutal?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/FatihArridho/brutal"><img title="Open Source" src="https://badges.frapsoft.com/os/v2/open-source.svg?v=103"></a>
<a href="https://github.com/FatihArridho/brutal"><img title="Size" src="https://img.shields.io/github/repo-size/FatihArridho/brutal?style=flat-square&color=green"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FFatihArridho%2Fbrutal&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
</p>
</div>

## NOTE
Jangan menyalahgunakan script ini, gunakan script ini dengan bijak. Dosa ditanggung yang pakai !

<h1 align="center">BRUTAL-SPAM-WA</h1>

Script Ini GRATIS buat kalian dan tidak di ENCRYPT. Mengapa? Supaya kalian bisa belajar recode dan mengerti tentang python.

## DOWNLOAD TERMUX FDROID
* Unduh & Install Termux [`Klik Disini`](https://f-droid.org/repo/com.termux_118.apk)

## FOR TERMUX/SSH USER
```bash
apt update && apt upgrade
apt install git -y
apt install python -y
git clone https://github.com/FatihArridho/brutal.git
cd brutal
pip install -r install.txt
python brutal.py
```

## FOR VPS UBUNTU USER
```bash
apt update && apt upgrade
apt install git -y
apt install python3-pip
git clone https://github.com/FatihArridho/brutal.git
cd brutal
pip3 install -r install.txt
python3 brutal.py
```

## UPDATE SCRIPT
```bash
cd brutal
git pull
```
